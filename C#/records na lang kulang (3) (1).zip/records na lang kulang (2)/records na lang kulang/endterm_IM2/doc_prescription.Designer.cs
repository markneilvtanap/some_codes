﻿namespace endterm_IM2
{
    partial class doc_prescription
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(doc_prescription));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.studagesss = new System.Windows.Forms.Label();
            this.textbox_studage = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textbox_courseProgram = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textbox_Lname = new System.Windows.Forms.TextBox();
            this.textbox_fName = new System.Windows.Forms.TextBox();
            this.textbox_stud_id = new System.Windows.Forms.TextBox();
            this.textbox_yearlevel = new System.Windows.Forms.TextBox();
            this.textbox_sex = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textbox_med_take = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textbox_med_dosage = new System.Windows.Forms.TextBox();
            this.textbox_medicine = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textbox_treatment = new System.Windows.Forms.TextBox();
            this.textbox_diagnosis = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dateTimePicker1VisitDate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1171, 134);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 151;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(773, 210);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(383, 334);
            this.dataGridView1.TabIndex = 152;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(773, 183);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(383, 22);
            this.textBox1.TabIndex = 153;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(779, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 154;
            this.label1.Text = "Search";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(781, 158);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 7);
            this.flowLayoutPanel1.TabIndex = 155;
            // 
            // studagesss
            // 
            this.studagesss.AutoSize = true;
            this.studagesss.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studagesss.Location = new System.Drawing.Point(421, 247);
            this.studagesss.Name = "studagesss";
            this.studagesss.Size = new System.Drawing.Size(36, 18);
            this.studagesss.TabIndex = 181;
            this.studagesss.Text = "Age";
            this.studagesss.Click += new System.EventHandler(this.studagesss_Click);
            // 
            // textbox_studage
            // 
            this.textbox_studage.Location = new System.Drawing.Point(425, 268);
            this.textbox_studage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_studage.Name = "textbox_studage";
            this.textbox_studage.Size = new System.Drawing.Size(141, 22);
            this.textbox_studage.TabIndex = 180;
            this.textbox_studage.TextChanged += new System.EventHandler(this.studage_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(193, 183);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 18);
            this.label10.TabIndex = 170;
            this.label10.Text = "Course/Program";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // textbox_courseProgram
            // 
            this.textbox_courseProgram.Location = new System.Drawing.Point(196, 204);
            this.textbox_courseProgram.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_courseProgram.Name = "textbox_courseProgram";
            this.textbox_courseProgram.Size = new System.Drawing.Size(204, 22);
            this.textbox_courseProgram.TabIndex = 169;
            this.textbox_courseProgram.TextChanged += new System.EventHandler(this.courseProgram_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(421, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 18);
            this.label5.TabIndex = 166;
            this.label5.Text = "Year Level";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(779, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 18);
            this.label4.TabIndex = 165;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(193, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 18);
            this.label3.TabIndex = 164;
            this.label3.Text = "Lastname";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 18);
            this.label2.TabIndex = 163;
            this.label2.Text = "Firstname";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 183);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 18);
            this.label11.TabIndex = 162;
            this.label11.Text = "Student ID NO.";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // textbox_Lname
            // 
            this.textbox_Lname.Location = new System.Drawing.Point(196, 268);
            this.textbox_Lname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_Lname.Name = "textbox_Lname";
            this.textbox_Lname.Size = new System.Drawing.Size(204, 22);
            this.textbox_Lname.TabIndex = 158;
            this.textbox_Lname.TextChanged += new System.EventHandler(this.Lname_TextChanged);
            // 
            // textbox_fName
            // 
            this.textbox_fName.Location = new System.Drawing.Point(5, 268);
            this.textbox_fName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_fName.Name = "textbox_fName";
            this.textbox_fName.Size = new System.Drawing.Size(172, 22);
            this.textbox_fName.TabIndex = 157;
            this.textbox_fName.TextChanged += new System.EventHandler(this.fName_TextChanged);
            // 
            // textbox_stud_id
            // 
            this.textbox_stud_id.Location = new System.Drawing.Point(5, 206);
            this.textbox_stud_id.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_stud_id.Name = "textbox_stud_id";
            this.textbox_stud_id.Size = new System.Drawing.Size(172, 22);
            this.textbox_stud_id.TabIndex = 156;
            this.textbox_stud_id.TextChanged += new System.EventHandler(this.stud_id_TextChanged);
            // 
            // textbox_yearlevel
            // 
            this.textbox_yearlevel.Location = new System.Drawing.Point(425, 206);
            this.textbox_yearlevel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_yearlevel.Name = "textbox_yearlevel";
            this.textbox_yearlevel.Size = new System.Drawing.Size(141, 22);
            this.textbox_yearlevel.TabIndex = 182;
            // 
            // textbox_sex
            // 
            this.textbox_sex.Location = new System.Drawing.Point(597, 206);
            this.textbox_sex.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_sex.Name = "textbox_sex";
            this.textbox_sex.Size = new System.Drawing.Size(163, 22);
            this.textbox_sex.TabIndex = 184;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(595, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 18);
            this.label6.TabIndex = 183;
            this.label6.Text = "Sex";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(445, 354);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 18);
            this.label8.TabIndex = 192;
            this.label8.Text = "Medicine Take";
            this.label8.Click += new System.EventHandler(this.label8_Click_1);
            // 
            // textbox_med_take
            // 
            this.textbox_med_take.Location = new System.Drawing.Point(448, 375);
            this.textbox_med_take.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_med_take.Multiline = true;
            this.textbox_med_take.Name = "textbox_med_take";
            this.textbox_med_take.Size = new System.Drawing.Size(155, 29);
            this.textbox_med_take.TabIndex = 191;
            this.textbox_med_take.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(235, 354);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 18);
            this.label9.TabIndex = 190;
            this.label9.Text = "Medicine Dosage";
            this.label9.Click += new System.EventHandler(this.label9_Click_1);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(16, 354);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 18);
            this.label12.TabIndex = 189;
            this.label12.Text = "Medicine";
            // 
            // textbox_med_dosage
            // 
            this.textbox_med_dosage.Location = new System.Drawing.Point(237, 375);
            this.textbox_med_dosage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_med_dosage.Multiline = true;
            this.textbox_med_dosage.Name = "textbox_med_dosage";
            this.textbox_med_dosage.Size = new System.Drawing.Size(185, 29);
            this.textbox_med_dosage.TabIndex = 188;
            this.textbox_med_dosage.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textbox_medicine
            // 
            this.textbox_medicine.Location = new System.Drawing.Point(19, 375);
            this.textbox_medicine.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_medicine.Multiline = true;
            this.textbox_medicine.Name = "textbox_medicine";
            this.textbox_medicine.Size = new System.Drawing.Size(185, 29);
            this.textbox_medicine.TabIndex = 187;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(327, 455);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 18);
            this.label13.TabIndex = 196;
            this.label13.Text = "Treatment";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(16, 455);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 18);
            this.label14.TabIndex = 195;
            this.label14.Text = "Diagnosis";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // textbox_treatment
            // 
            this.textbox_treatment.Location = new System.Drawing.Point(331, 478);
            this.textbox_treatment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_treatment.Multiline = true;
            this.textbox_treatment.Name = "textbox_treatment";
            this.textbox_treatment.Size = new System.Drawing.Size(345, 75);
            this.textbox_treatment.TabIndex = 194;
            // 
            // textbox_diagnosis
            // 
            this.textbox_diagnosis.Location = new System.Drawing.Point(19, 478);
            this.textbox_diagnosis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_diagnosis.Multiline = true;
            this.textbox_diagnosis.Name = "textbox_diagnosis";
            this.textbox_diagnosis.Size = new System.Drawing.Size(272, 75);
            this.textbox_diagnosis.TabIndex = 193;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 153);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 22);
            this.label15.TabIndex = 197;
            this.label15.Text = "Student INFO";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 313);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 22);
            this.label16.TabIndex = 198;
            this.label16.Text = "Medicine INFO";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(15, 425);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(182, 22);
            this.label17.TabIndex = 199;
            this.label17.Text = "Doctor Prescription";
            // 
            // dateTimePicker1VisitDate
            // 
            this.dateTimePicker1VisitDate.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1VisitDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1VisitDate.Location = new System.Drawing.Point(627, 375);
            this.dateTimePicker1VisitDate.Name = "dateTimePicker1VisitDate";
            this.dateTimePicker1VisitDate.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker1VisitDate.TabIndex = 200;
            this.dateTimePicker1VisitDate.ValueChanged += new System.EventHandler(this.dateTimePicker1VisitDate_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(624, 354);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 18);
            this.label7.TabIndex = 201;
            this.label7.Text = "Visit Date";
            // 
            // doc_prescription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1VisitDate);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textbox_treatment);
            this.Controls.Add(this.textbox_diagnosis);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textbox_med_take);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textbox_med_dosage);
            this.Controls.Add(this.textbox_medicine);
            this.Controls.Add(this.textbox_sex);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textbox_yearlevel);
            this.Controls.Add(this.studagesss);
            this.Controls.Add(this.textbox_studage);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textbox_courseProgram);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textbox_Lname);
            this.Controls.Add(this.textbox_fName);
            this.Controls.Add(this.textbox_stud_id);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "doc_prescription";
            this.Size = new System.Drawing.Size(1182, 628);
            this.Load += new System.EventHandler(this.doc_prescription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label studagesss;
        private System.Windows.Forms.TextBox textbox_studage;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textbox_courseProgram;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textbox_Lname;
        private System.Windows.Forms.TextBox textbox_fName;
        private System.Windows.Forms.TextBox textbox_stud_id;
        private System.Windows.Forms.TextBox textbox_yearlevel;
        private System.Windows.Forms.TextBox textbox_sex;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textbox_med_take;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textbox_med_dosage;
        private System.Windows.Forms.TextBox textbox_medicine;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textbox_treatment;
        private System.Windows.Forms.TextBox textbox_diagnosis;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dateTimePicker1VisitDate;
        private System.Windows.Forms.Label label7;
    }
}
