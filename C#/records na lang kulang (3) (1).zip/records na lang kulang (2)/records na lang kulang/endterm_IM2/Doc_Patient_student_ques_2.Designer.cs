﻿namespace endterm_IM2
{
    partial class Doc_Patient_student_ques_2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Doc_Patient_student_ques_2));
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.curr_symptoms1 = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.curr_symptoms2 = new System.Windows.Forms.TextBox();
            this.habits = new System.Windows.Forms.TextBox();
            this.vaccine = new System.Windows.Forms.TextBox();
            this.mentalHealth2 = new System.Windows.Forms.TextBox();
            this.lifestylexx = new System.Windows.Forms.TextBox();
            this.mentalHealth1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(264, 121);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(380, 31);
            this.label11.TabIndex = 151;
            this.label11.Text = "Patient/Student Questions 2";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(878, 109);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 150;
            this.pictureBox1.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(449, 322);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 18);
            this.label22.TabIndex = 167;
            this.label22.Text = "History: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(10, 409);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(389, 26);
            this.label18.TabIndex = 165;
            this.label18.Text = " Are you currently seeing a mental health professional or taking any\r\n psychiatri" +
    "c medications? ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 349);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(401, 13);
            this.label19.TabIndex = 163;
            this.label19.Text = "Have you experienced any significant stress or life changes recently?";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(8, 322);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 18);
            this.label20.TabIndex = 162;
            this.label20.Text = "Mental Health: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(460, 189);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(327, 13);
            this.label15.TabIndex = 160;
            this.label15.Text = " How much alcohol do you consume on a regular basis? ";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(455, 248);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(405, 26);
            this.label16.TabIndex = 158;
            this.label16.Text = "Do you smoke or use tobacco products? If so, how much and for how \r\nlong?";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(449, 163);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(164, 18);
            this.label12.TabIndex = 157;
            this.label12.Text = "Lifestyle and Habbits";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(2, 261);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(420, 26);
            this.label9.TabIndex = 155;
            this.label9.Text = "When did your symptoms start, and have they changed or worsened over\r\n time?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(8, 189);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(414, 26);
            this.label10.TabIndex = 153;
            this.label10.Text = "What brings you to the clinic today? Can you describe your symptoms in\r\n detail? " +
    "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 163);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 18);
            this.label8.TabIndex = 152;
            this.label8.Text = "Current Symptoms:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(453, 349);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(341, 13);
            this.label21.TabIndex = 168;
            this.label21.Text = "What type of vaccine did you take (e.g., Moderna, Pfizer)?";
            // 
            // curr_symptoms1
            // 
            this.curr_symptoms1.Location = new System.Drawing.Point(8, 217);
            this.curr_symptoms1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.curr_symptoms1.Multiline = true;
            this.curr_symptoms1.Name = "curr_symptoms1";
            this.curr_symptoms1.Size = new System.Drawing.Size(418, 32);
            this.curr_symptoms1.TabIndex = 170;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // curr_symptoms2
            // 
            this.curr_symptoms2.Location = new System.Drawing.Point(8, 288);
            this.curr_symptoms2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.curr_symptoms2.Multiline = true;
            this.curr_symptoms2.Name = "curr_symptoms2";
            this.curr_symptoms2.Size = new System.Drawing.Size(418, 32);
            this.curr_symptoms2.TabIndex = 172;
            // 
            // habits
            // 
            this.habits.Location = new System.Drawing.Point(452, 210);
            this.habits.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.habits.Multiline = true;
            this.habits.Name = "habits";
            this.habits.Size = new System.Drawing.Size(405, 32);
            this.habits.TabIndex = 173;
            // 
            // vaccine
            // 
            this.vaccine.Location = new System.Drawing.Point(455, 372);
            this.vaccine.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.vaccine.Multiline = true;
            this.vaccine.Name = "vaccine";
            this.vaccine.Size = new System.Drawing.Size(402, 32);
            this.vaccine.TabIndex = 174;
            // 
            // mentalHealth2
            // 
            this.mentalHealth2.Location = new System.Drawing.Point(8, 437);
            this.mentalHealth2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mentalHealth2.Multiline = true;
            this.mentalHealth2.Name = "mentalHealth2";
            this.mentalHealth2.Size = new System.Drawing.Size(418, 32);
            this.mentalHealth2.TabIndex = 175;
            // 
            // lifestylexx
            // 
            this.lifestylexx.Location = new System.Drawing.Point(452, 274);
            this.lifestylexx.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lifestylexx.Multiline = true;
            this.lifestylexx.Name = "lifestylexx";
            this.lifestylexx.Size = new System.Drawing.Size(405, 32);
            this.lifestylexx.TabIndex = 176;
            // 
            // mentalHealth1
            // 
            this.mentalHealth1.Location = new System.Drawing.Point(8, 368);
            this.mentalHealth1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mentalHealth1.Multiline = true;
            this.mentalHealth1.Name = "mentalHealth1";
            this.mentalHealth1.Size = new System.Drawing.Size(418, 32);
            this.mentalHealth1.TabIndex = 177;
            // 
            // Doc_Patient_student_ques_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.mentalHealth1);
            this.Controls.Add(this.lifestylexx);
            this.Controls.Add(this.mentalHealth2);
            this.Controls.Add(this.vaccine);
            this.Controls.Add(this.habits);
            this.Controls.Add(this.curr_symptoms2);
            this.Controls.Add(this.curr_symptoms1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Doc_Patient_student_ques_2";
            this.Size = new System.Drawing.Size(886, 490);
            this.Load += new System.EventHandler(this.Doc_Patient_student_ques_2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox curr_symptoms1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox curr_symptoms2;
        private System.Windows.Forms.TextBox habits;
        private System.Windows.Forms.TextBox vaccine;
        private System.Windows.Forms.TextBox mentalHealth2;
        private System.Windows.Forms.TextBox lifestylexx;
        private System.Windows.Forms.TextBox mentalHealth1;
    }
}
