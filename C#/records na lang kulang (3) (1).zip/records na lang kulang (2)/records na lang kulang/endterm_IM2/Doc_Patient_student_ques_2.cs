﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace endterm_IM2
{
    public partial class Doc_Patient_student_ques_2 : UserControl
    {
        public TextBox currsymp1;
        public TextBox currsymp2;
        public TextBox lifeStyle;
        public TextBox habitsx;
        public TextBox men_health1;
        public TextBox men_health2;
        public TextBox vac_history;


        public Doc_Patient_student_ques_2()
        {
            InitializeComponent();
           currsymp1 = this.curr_symptoms1;
           currsymp2=  this.curr_symptoms2;
            lifeStyle = this.lifestylexx;
           habitsx = this.habits;
           men_health1 = this.mentalHealth1;
          men_health2 = this.mentalHealth2;
            vac_history = this.vaccine;

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void Doc_Patient_student_ques_2_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox13_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
