﻿namespace endterm_IM2
{
    partial class admin_doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admin_doctor));
            this.label14 = new System.Windows.Forms.Label();
            this.doc_pass = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Doc_username = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Doc_experience = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Doc_address = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Doc_age = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Doc_Fname = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Doc_specialization = new System.Windows.Forms.TextBox();
            this.Doc_position = new System.Windows.Forms.TextBox();
            this.Doc_email = new System.Windows.Forms.TextBox();
            this.Doc_contact_no = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Doc_LName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Doc_search = new System.Windows.Forms.TextBox();
            this.Doc_datagridView = new System.Windows.Forms.DataGridView();
            this.Doc_cancel = new System.Windows.Forms.Button();
            this.Doc_delete = new System.Windows.Forms.Button();
            this.Doc_edit = new System.Windows.Forms.Button();
            this.Doc_add = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.Doc_datagridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(221, 470);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 15);
            this.label14.TabIndex = 65;
            this.label14.Text = "Password";
            // 
            // doc_pass
            // 
            this.doc_pass.Location = new System.Drawing.Point(224, 491);
            this.doc_pass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.doc_pass.Name = "doc_pass";
            this.doc_pass.Size = new System.Drawing.Size(185, 20);
            this.doc_pass.TabIndex = 64;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(22, 473);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 15);
            this.label15.TabIndex = 63;
            this.label15.Text = "Username";
            // 
            // Doc_username
            // 
            this.Doc_username.Location = new System.Drawing.Point(22, 490);
            this.Doc_username.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_username.Name = "Doc_username";
            this.Doc_username.Size = new System.Drawing.Size(185, 20);
            this.Doc_username.TabIndex = 62;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(24, 373);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 15);
            this.label13.TabIndex = 61;
            this.label13.Text = "Experience";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // Doc_experience
            // 
            this.Doc_experience.Location = new System.Drawing.Point(24, 390);
            this.Doc_experience.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_experience.Multiline = true;
            this.Doc_experience.Name = "Doc_experience";
            this.Doc_experience.Size = new System.Drawing.Size(260, 36);
            this.Doc_experience.TabIndex = 60;
            this.Doc_experience.TextChanged += new System.EventHandler(this.Doc_experience_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 116);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 15);
            this.label12.TabIndex = 59;
            this.label12.Text = "Address";
            // 
            // Doc_address
            // 
            this.Doc_address.Location = new System.Drawing.Point(22, 133);
            this.Doc_address.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_address.Multiline = true;
            this.Doc_address.Name = "Doc_address";
            this.Doc_address.Size = new System.Drawing.Size(260, 30);
            this.Doc_address.TabIndex = 58;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(295, 68);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 15);
            this.label11.TabIndex = 57;
            this.label11.Text = "Date of Birth";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 15);
            this.label3.TabIndex = 55;
            this.label3.Text = "Age";
            // 
            // Doc_age
            // 
            this.Doc_age.Location = new System.Drawing.Point(22, 87);
            this.Doc_age.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_age.Name = "Doc_age";
            this.Doc_age.Size = new System.Drawing.Size(76, 20);
            this.Doc_age.TabIndex = 53;
            this.Doc_age.TextChanged += new System.EventHandler(this.Doc_age_TextChanged);
            this.Doc_age.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Doc_age_KeyPress);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(298, 87);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(116, 20);
            this.dateTimePicker1.TabIndex = 52;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Doc_Fname
            // 
            this.Doc_Fname.Location = new System.Drawing.Point(22, 38);
            this.Doc_Fname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_Fname.Name = "Doc_Fname";
            this.Doc_Fname.Size = new System.Drawing.Size(189, 20);
            this.Doc_Fname.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(23, 329);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 15);
            this.label7.TabIndex = 50;
            this.label7.Text = "Specialization";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(24, 288);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 15);
            this.label8.TabIndex = 49;
            this.label8.Text = "Position";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 205);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 15);
            this.label9.TabIndex = 48;
            this.label9.Text = "Email";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(22, 165);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 15);
            this.label10.TabIndex = 47;
            this.label10.Text = "Contact No.";
            // 
            // Doc_specialization
            // 
            this.Doc_specialization.Location = new System.Drawing.Point(23, 346);
            this.Doc_specialization.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_specialization.Name = "Doc_specialization";
            this.Doc_specialization.Size = new System.Drawing.Size(258, 20);
            this.Doc_specialization.TabIndex = 46;
            this.Doc_specialization.TextChanged += new System.EventHandler(this.Doc_specialization_TextChanged);
            // 
            // Doc_position
            // 
            this.Doc_position.Location = new System.Drawing.Point(24, 306);
            this.Doc_position.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_position.Name = "Doc_position";
            this.Doc_position.Size = new System.Drawing.Size(185, 20);
            this.Doc_position.TabIndex = 45;
            this.Doc_position.TextChanged += new System.EventHandler(this.Doc_position_TextChanged);
            // 
            // Doc_email
            // 
            this.Doc_email.Location = new System.Drawing.Point(23, 221);
            this.Doc_email.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_email.Name = "Doc_email";
            this.Doc_email.Size = new System.Drawing.Size(258, 20);
            this.Doc_email.TabIndex = 44;
            // 
            // Doc_contact_no
            // 
            this.Doc_contact_no.Location = new System.Drawing.Point(24, 181);
            this.Doc_contact_no.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_contact_no.Name = "Doc_contact_no";
            this.Doc_contact_no.Size = new System.Drawing.Size(187, 20);
            this.Doc_contact_no.TabIndex = 43;
            this.Doc_contact_no.TextChanged += new System.EventHandler(this.Doc_contact_no_TextChanged);
            this.Doc_contact_no.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Doc_contact_no_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(220, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 15);
            this.label6.TabIndex = 42;
            this.label6.Text = "Lastname";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 22);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 41;
            this.label5.Text = "Firstname";
            // 
            // Doc_LName
            // 
            this.Doc_LName.Location = new System.Drawing.Point(224, 38);
            this.Doc_LName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_LName.Name = "Doc_LName";
            this.Doc_LName.Size = new System.Drawing.Size(189, 20);
            this.Doc_LName.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(427, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 68;
            this.label1.Text = "Search";
            // 
            // Doc_search
            // 
            this.Doc_search.Location = new System.Drawing.Point(430, 38);
            this.Doc_search.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_search.Name = "Doc_search";
            this.Doc_search.Size = new System.Drawing.Size(445, 20);
            this.Doc_search.TabIndex = 67;
            this.Doc_search.TextChanged += new System.EventHandler(this.Doc_search_TextChanged);
            // 
            // Doc_datagridView
            // 
            this.Doc_datagridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Doc_datagridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Doc_datagridView.Location = new System.Drawing.Point(430, 73);
            this.Doc_datagridView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_datagridView.Name = "Doc_datagridView";
            this.Doc_datagridView.RowHeadersWidth = 51;
            this.Doc_datagridView.RowTemplate.Height = 24;
            this.Doc_datagridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Doc_datagridView.Size = new System.Drawing.Size(445, 399);
            this.Doc_datagridView.TabIndex = 66;
            this.Doc_datagridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Doc_datagridView_CellContentClick);
            this.Doc_datagridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Doc_datagridView_CellMouseClick);
            // 
            // Doc_cancel
            // 
            this.Doc_cancel.BackColor = System.Drawing.Color.Gold;
            this.Doc_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doc_cancel.Location = new System.Drawing.Point(694, 482);
            this.Doc_cancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_cancel.Name = "Doc_cancel";
            this.Doc_cancel.Size = new System.Drawing.Size(75, 36);
            this.Doc_cancel.TabIndex = 72;
            this.Doc_cancel.Text = "CANCEL";
            this.Doc_cancel.UseVisualStyleBackColor = false;
            this.Doc_cancel.Click += new System.EventHandler(this.Doc_cancel_Click);
            // 
            // Doc_delete
            // 
            this.Doc_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Doc_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doc_delete.Location = new System.Drawing.Point(611, 482);
            this.Doc_delete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_delete.Name = "Doc_delete";
            this.Doc_delete.Size = new System.Drawing.Size(70, 36);
            this.Doc_delete.TabIndex = 71;
            this.Doc_delete.Text = "DELETE";
            this.Doc_delete.UseVisualStyleBackColor = false;
            this.Doc_delete.Click += new System.EventHandler(this.Doc_delete_Click);
            // 
            // Doc_edit
            // 
            this.Doc_edit.BackColor = System.Drawing.Color.Gold;
            this.Doc_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doc_edit.Location = new System.Drawing.Point(528, 482);
            this.Doc_edit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_edit.Name = "Doc_edit";
            this.Doc_edit.Size = new System.Drawing.Size(68, 36);
            this.Doc_edit.TabIndex = 70;
            this.Doc_edit.Text = "EDIT";
            this.Doc_edit.UseVisualStyleBackColor = false;
            this.Doc_edit.Click += new System.EventHandler(this.Doc_edit_Click);
            // 
            // Doc_add
            // 
            this.Doc_add.BackColor = System.Drawing.Color.Gold;
            this.Doc_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doc_add.Location = new System.Drawing.Point(441, 482);
            this.Doc_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Doc_add.Name = "Doc_add";
            this.Doc_add.Size = new System.Drawing.Size(74, 36);
            this.Doc_add.TabIndex = 69;
            this.Doc_add.Text = "ADD";
            this.Doc_add.UseVisualStyleBackColor = false;
            this.Doc_add.Click += new System.EventHandler(this.Doc_add_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(123, 68);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(146, 46);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sex";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 25);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(57, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(78, 25);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 19);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 249);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 75;
            this.label2.Text = "Licence Number";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(24, 266);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(258, 20);
            this.textBox1.TabIndex = 74;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 448);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 18);
            this.label4.TabIndex = 76;
            this.label4.Text = "Doctor Account";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(783, 482);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 77;
            this.button1.Text = "PRINT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // admin_doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(886, 525);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Doc_cancel);
            this.Controls.Add(this.Doc_delete);
            this.Controls.Add(this.Doc_edit);
            this.Controls.Add(this.Doc_add);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Doc_search);
            this.Controls.Add(this.Doc_datagridView);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.doc_pass);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.Doc_username);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Doc_experience);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Doc_address);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Doc_age);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Doc_Fname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Doc_specialization);
            this.Controls.Add(this.Doc_position);
            this.Controls.Add(this.Doc_email);
            this.Controls.Add(this.Doc_contact_no);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Doc_LName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "admin_doctor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "doctor_admin";
            this.Load += new System.EventHandler(this.doctor_admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Doc_datagridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox doc_pass;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Doc_username;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Doc_experience;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Doc_address;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Doc_age;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox Doc_Fname;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Doc_specialization;
        private System.Windows.Forms.TextBox Doc_position;
        private System.Windows.Forms.TextBox Doc_email;
        private System.Windows.Forms.TextBox Doc_contact_no;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Doc_LName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Doc_search;
        private System.Windows.Forms.DataGridView Doc_datagridView;
        private System.Windows.Forms.Button Doc_cancel;
        private System.Windows.Forms.Button Doc_delete;
        private System.Windows.Forms.Button Doc_edit;
        private System.Windows.Forms.Button Doc_add;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}